import { DataTable } from "./DataTable";

function App() {
  return <DataTable />;
}

export default App;