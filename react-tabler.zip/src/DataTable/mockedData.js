// TODO: use faker.js for values

export const colorOptions = [
  { value: 'red', label: 'Red' },
  { value: 'green', label: 'Green' },
  { value: 'blue', label: 'Blue' },
  { value: 'yellow', label: 'Yellow' }
]

export function generateData(rows, subRows) {
  const data = {
    columns: [
      { id: 'name', ordinalNo: 1, title: 'Name', type: 'string', width: 100 },
      { id: 'weight', ordinalNo: 2, title: 'Weight', type: 'number', width: 100 },
      { id: 'isAvailable', ordinalNo: 3, title: 'Availability', type: 'boolean', width: 100 },
      { id: 'color', ordinalNo: 4, title: 'Color', type: 'select', width: 150 },
    ],
    data: [],
  };

  for (let i = 1; i <= rows; i++) {
    const row = {
      id: i.toString(),
      name: `Name ${i}`,
      weight: 30,
      isAvailable: i % 2 === 0,
      color: ['red', 'blue', 'yellow', 'green'][i % 4],
      subRows: [],
    };

    for (let j = 1; j <= subRows; j++) {
      const subRowId = `${i}.${j}`;
      const subRow = {
        id: subRowId,
        name: `Name ${subRowId}`,
        weight: 30,
        isAvailable: j % 2 === 0,
        color: ['red', 'blue', 'yellow', 'green'][j % 4],
      };
      row.subRows.push(subRow);
    }

    data.data.push(row);
  }

  return data;
}