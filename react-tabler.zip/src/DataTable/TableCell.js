import { useState, useEffect } from "react";
import "./dataTable.css";

export const TableCell = ({ getValue, row, column, table }) => {
  const initialValue = getValue();
  const columnMeta = column.columnDef.meta;
  const tableMeta = table.options.meta;
  const [value, setValue] = useState(initialValue);

  const COLUMN_INDEX_WITH_EXPANDER = 0;

  useEffect(() => {
    setValue(initialValue);
  }, [initialValue]);

  const onBlur = (e) => {
    tableMeta?.updateData(row.index, column.id, value);
  };

  const onSelectChange = (e) => {
    setValue(e.target.value);
    tableMeta?.updateData(row.index, column.id, e.target.value);
  };

  const onCheckChange = (e) => {
    setValue(e.target.checked);
    tableMeta?.updateData(row.index, column.id, e.target.checked);
  };

  const renderCellType = (type) => {
    let el;
    // TODO: change on switch-else
    if (type === "select") {
      el = (<select
        onChange={onSelectChange}
        value={initialValue}
      >
        {columnMeta?.options?.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>);
    }
    if (type === "boolean") {
      el = (<input
        checked={value}
        onChange={(e) => onCheckChange(e)}
        type="checkbox"
      />);
    }
    if (type === "string" || type === "number") {
      el = (<input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onBlur={onBlur}
        type={columnMeta?.type || "text"}
      />);
    }

    return (
      <div style={{ paddingLeft: columnMeta.columnIndex === COLUMN_INDEX_WITH_EXPANDER ? `${row.depth * 2}rem` : "0px" }} >
        {row.getCanExpand() && columnMeta.columnIndex === COLUMN_INDEX_WITH_EXPANDER ? (
          // TODO: fix style
          <button
            {...{
              onClick: row.getToggleExpandedHandler(),
              style: { cursor: 'pointer', marginRight: '10px', width: "16px" },
            }}
          >
            {row.getIsExpanded() ? '-' : '+'}
          </button>
        ) : <span style={{display: "inline-block", width: "26px"}}/>}
        {el}
      </div>
    )
    
  }
  
  return renderCellType(columnMeta?.type);
};