import { generateData } from "./DataTable/mockedData";

export function fakeFetch(rows, subRows) {
  // export function fakeFetch(url, {rows, subRows}) {
  return new Promise((resolve) => {
    const delay = 1000 + Math.random() * 1000;

    setTimeout(() => {
      // if (url) {
      //   res = gD()
      // } 
      // if (url) {
      //   res = gC()
      // } 
      const result = generateData(rows, subRows);
      resolve(result);
    }, delay);
  });
}
